module.exports = {
    'secret': 'Sdk.fiware2017',  //secret key for our JSON Web Token.
    'database': 'mongodb://admin:admin@ds125195.mlab.com:25195/smartsecurityfdm'
    //'database':'mongodb://localhost:27017/smartsecurityfdm'
};